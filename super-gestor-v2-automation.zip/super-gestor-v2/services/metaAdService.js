// ============================================================
// services/metaAdService.js
// Criação e gerenciamento de anúncios individuais
// ============================================================

const fetch = require('node-fetch');

const META_BASE  = 'https://graph.facebook.com/v19.0';
const TOKEN      = process.env.META_ACCESS_TOKEN;
const AD_ACCOUNT = process.env.META_AD_ACCOUNT_ID;

// ─── 1. Criar anúncio ─────────────────────────────────────
async function createAd({
  adset_id,
  creative_id,
  nome,
  status = 'PAUSED', // sempre PAUSED por segurança
}) {
  const url  = `${META_BASE}/${AD_ACCOUNT}/ads`;
  const body = {
    name:         nome,
    adset_id,
    creative:     JSON.stringify({ creative_id }),
    status,
    access_token: TOKEN,
  };

  const res  = await fetch(url, {
    method:  'POST',
    headers: { 'Content-Type': 'application/json' },
    body:    JSON.stringify(body),
  });
  const data = await res.json();

  if (data.error) throw new Error(`[createAd] ${data.error.message}`);
  return { ad_id: data.id, nome, adset_id, creative_id, status };
}

// ─── 2. Listar anúncios de um ad set ─────────────────────
async function listAds(adset_id) {
  const url  = `${META_BASE}/${adset_id}/ads`
    + `?fields=id,name,status,adset_id,creative,effective_status`
    + `&access_token=${TOKEN}`;

  const res  = await fetch(url);
  const data = await res.json();

  if (data.error) throw new Error(`[listAds] ${data.error.message}`);
  return data.data || [];
}

// ─── 3. Buscar métricas de anúncios ──────────────────────
async function getAdMetrics(ad_id, periodo = 'last_30d') {
  const fields = [
    'impressions', 'clicks', 'spend',
    'cpm', 'cpc', 'ctr',
    'actions', 'action_values',
    'frequency', 'reach',
    'cost_per_action_type',
  ].join(',');

  const url  = `${META_BASE}/${ad_id}/insights`
    + `?fields=${fields}&date_preset=${periodo}&access_token=${TOKEN}`;

  const res  = await fetch(url);
  const data = await res.json();

  if (data.error) throw new Error(`[getAdMetrics] ${data.error.message}`);

  const m = data.data?.[0] || {};

  // Extrai ROAS das actions
  const purchase_value = m.action_values?.find(a => a.action_type === 'purchase')?.value || 0;
  const roas           = m.spend && purchase_value > 0 ? (purchase_value / m.spend).toFixed(2) : null;

  // Extrai conversões (compras)
  const conversoes = m.actions?.find(a => a.action_type === 'purchase')?.value || 0;

  return {
    ad_id,
    impressions: parseInt(m.impressions || 0),
    clicks:      parseInt(m.clicks || 0),
    spend:       parseFloat(m.spend || 0),
    cpm:         parseFloat(m.cpm || 0),
    cpc:         parseFloat(m.cpc || 0),
    ctr:         parseFloat(m.ctr || 0),
    frequency:   parseFloat(m.frequency || 0),
    reach:       parseInt(m.reach || 0),
    roas:        roas ? parseFloat(roas) : null,
    conversoes:  parseInt(conversoes),
  };
}

// ─── 4. Pausar anúncio ────────────────────────────────────
async function pauseAd(ad_id) {
  return _updateAdStatus(ad_id, 'PAUSED');
}

// ─── 5. Ativar anúncio ────────────────────────────────────
async function activateAd(ad_id) {
  return _updateAdStatus(ad_id, 'ACTIVE');
}

// ─── 6. Criar múltiplos anúncios (A/B) ───────────────────
async function createMultipleAds({ adset_id, creative_ids, nome_base }) {
  const ads = [];

  for (let i = 0; i < creative_ids.length; i++) {
    const variacao = String.fromCharCode(65 + i); // A, B, C...
    const ad = await createAd({
      adset_id,
      creative_id: creative_ids[i],
      nome:        `${nome_base} | Variação ${variacao}`,
      status:      'PAUSED',
    });
    ads.push({ ...ad, variacao });
  }

  return ads;
}

// ─── Helper: atualizar status ─────────────────────────────
async function _updateAdStatus(ad_id, status) {
  const url  = `${META_BASE}/${ad_id}`;
  const body = { status, access_token: TOKEN };

  const res  = await fetch(url, {
    method:  'POST',
    headers: { 'Content-Type': 'application/json' },
    body:    JSON.stringify(body),
  });
  const data = await res.json();

  if (data.error) throw new Error(`[updateAdStatus] ${data.error.message}`);
  return { ad_id, status, success: true };
}

module.exports = {
  createAd,
  listAds,
  getAdMetrics,
  pauseAd,
  activateAd,
  createMultipleAds,
};
