// ============================================================
// services/creativeService.js
// Upload de imagens e criação de ad creatives no Meta Ads
// ============================================================

const fetch = require('node-fetch');
const FormData = require('form-data');

const META_BASE  = 'https://graph.facebook.com/v19.0';
const TOKEN      = process.env.META_ACCESS_TOKEN;
const AD_ACCOUNT = process.env.META_AD_ACCOUNT_ID;

// ─── 1. Upload de imagem via URL ──────────────────────────
// Faz download da imagem e envia para o Meta
async function uploadImageFromUrl(image_url) {
  // Baixa a imagem como buffer
  const imgRes    = await fetch(image_url);
  const imgBuffer = await imgRes.buffer();
  const mimeType  = imgRes.headers.get('content-type') || 'image/jpeg';
  const ext       = mimeType.includes('png') ? 'png' : 'jpg';

  // Faz upload para o Meta
  const form = new FormData();
  form.append('access_token', TOKEN);
  form.append('filename', `creative_${Date.now()}.${ext}`, {
    contentType: mimeType,
    filename:    `creative.${ext}`,
  });

  const url  = `${META_BASE}/${AD_ACCOUNT}/adimages`;
  const res  = await fetch(url, { method: 'POST', body: form });
  const data = await res.json();

  if (data.error) throw new Error(`[uploadImageFromUrl] ${data.error.message}`);

  // Retorna o hash da imagem
  const images = data.images;
  const hash   = images[Object.keys(images)[0]].hash;

  return { image_hash: hash, image_url };
}

// ─── 2. Upload de imagem via base64 ──────────────────────
async function uploadImageBase64(base64_data, filename = 'creative.jpg') {
  const url  = `${META_BASE}/${AD_ACCOUNT}/adimages`;
  const body = {
    bytes:        base64_data,
    name:         filename,
    access_token: TOKEN,
  };

  const res  = await fetch(url, {
    method:  'POST',
    headers: { 'Content-Type': 'application/json' },
    body:    JSON.stringify(body),
  });
  const data = await res.json();

  if (data.error) throw new Error(`[uploadImageBase64] ${data.error.message}`);

  const images = data.images;
  const hash   = images[Object.keys(images)[0]].hash;

  return { image_hash: hash };
}

// ─── 3. Criar ad creative (link ad) ──────────────────────
async function createAdCreative({
  nome,
  image_hash,
  page_id,           // Facebook Page ID (obrigatório)
  headline,
  primary_text,
  description,
  link_url,          // URL de destino
  cta = 'LEARN_MORE',
  instagram_actor_id = null,  // Instagram account ID (opcional)
}) {
  const url = `${META_BASE}/${AD_ACCOUNT}/adcreatives`;

  const object_story_spec = {
    page_id,
    link_data: {
      image_hash,
      link:        link_url,
      message:     primary_text,
      name:        headline,
      description,
      call_to_action: {
        type:  cta,
        value: { link: link_url },
      },
    },
  };

  // Adiciona conta do Instagram se fornecida
  if (instagram_actor_id) {
    object_story_spec.instagram_actor_id = instagram_actor_id;
  }

  const body = {
    name:                nome,
    object_story_spec:   JSON.stringify(object_story_spec),
    degrees_of_freedom_spec: JSON.stringify({
      creative_features_spec: {
        standard_enhancements: { enroll_status: 'OPT_OUT' },
      },
    }),
    access_token: TOKEN,
  };

  const res  = await fetch(url, {
    method:  'POST',
    headers: { 'Content-Type': 'application/json' },
    body:    JSON.stringify(body),
  });
  const data = await res.json();

  if (data.error) throw new Error(`[createAdCreative] ${data.error.message}`);
  return { creative_id: data.id, nome };
}

// ─── 4. Criar creative de vídeo ───────────────────────────
async function createVideoAdCreative({
  nome,
  video_id,          // ID de vídeo já enviado ao Meta
  thumbnail_url,
  page_id,
  headline,
  primary_text,
  description,
  link_url,
  cta = 'LEARN_MORE',
}) {
  const url = `${META_BASE}/${AD_ACCOUNT}/adcreatives`;

  const body = {
    name: nome,
    object_story_spec: JSON.stringify({
      page_id,
      video_data: {
        video_id,
        image_url:   thumbnail_url,
        message:     primary_text,
        title:       headline,
        link_description: description,
        call_to_action: {
          type:  cta,
          value: { link: link_url },
        },
      },
    }),
    access_token: TOKEN,
  };

  const res  = await fetch(url, {
    method:  'POST',
    headers: { 'Content-Type': 'application/json' },
    body:    JSON.stringify(body),
  });
  const data = await res.json();

  if (data.error) throw new Error(`[createVideoAdCreative] ${data.error.message}`);
  return { creative_id: data.id, nome };
}

// ─── 5. Criar múltiplos creatives (para A/B) ─────────────
async function createMultipleCreatives({ copies, image_hashes, page_id, link_url }) {
  const creatives = [];

  for (let i = 0; i < copies.length; i++) {
    const copy  = copies[i];
    const hash  = image_hashes[i % image_hashes.length]; // rotaciona imagens

    const creative = await createAdCreative({
      nome:         `Creative ${copy.id || i + 1} - ${Date.now()}`,
      image_hash:   hash,
      page_id,
      headline:     copy.headline,
      primary_text: copy.primary_text,
      description:  copy.description,
      link_url,
      cta:          copy.cta || 'LEARN_MORE',
    });

    creatives.push(creative);
  }

  return creatives;
}

// ─── 6. Gerar conceito de imagem (sem upload) ────────────
// Retorna prompt para usar em DALL-E / Midjourney / Stable Diffusion
function generateImagePrompt({ produto, publico, estilo = 'profissional', cores = [] }) {
  const coresStr = cores.length ? `Cores principais: ${cores.join(', ')}.` : '';

  return {
    prompt_dalle: `Professional marketing photo for "${produto}". Target audience: ${publico}. Style: ${estilo}, clean background, high quality, advertising photography. ${coresStr} No text.`,
    prompt_midjourney: `Professional ad creative for ${produto}, ${estilo} style, targeted at ${publico}, clean composition, commercial photography, high resolution, ${coresStr} --ar 1:1 --v 6`,
    instrucoes: 'Use este prompt em DALL-E 3 (OpenAI) ou Midjourney para gerar a imagem. Depois faça upload via /api/creative/upload-url',
  };
}

module.exports = {
  uploadImageFromUrl,
  uploadImageBase64,
  createAdCreative,
  createVideoAdCreative,
  createMultipleCreatives,
  generateImagePrompt,
};
