// ============================================================
// services/metaAdsetService.js
// Criação de conjuntos de anúncios + Audience Builder
// ============================================================

const fetch = require('node-fetch');
const Anthropic = require('@anthropic-ai/sdk');

const META_BASE  = 'https://graph.facebook.com/v19.0';
const TOKEN      = process.env.META_ACCESS_TOKEN;
const AD_ACCOUNT = process.env.META_AD_ACCOUNT_ID;
const anthropic  = new Anthropic({ apiKey: process.env.ANTHROPIC_API_KEY });

// ─── Mapeamentos ──────────────────────────────────────────
const OPTIMIZATION_GOAL_MAP = {
  conversoes:   'OFFSITE_CONVERSIONS',
  leads:        'LEAD_GENERATION',
  trafego:      'LINK_CLICKS',
  engajamento:  'POST_ENGAGEMENT',
  alcance:      'REACH',
  visualizacoes:'VIDEO_VIEWS',
};

const BILLING_EVENT_MAP = {
  conversoes:   'IMPRESSIONS',
  leads:        'IMPRESSIONS',
  trafego:      'LINK_CLICKS',
  engajamento:  'POST_ENGAGEMENT',
  alcance:      'IMPRESSIONS',
  visualizacoes:'IMPRESSIONS',
};

// ─── 1. AUDIENCE BUILDER com IA ───────────────────────────
// Gera targeting automático baseado no produto e público
async function buildAudience({ produto, pais = 'BR', idade_min = 18, idade_max = 65, objetivo = 'conversoes' }) {

  // Usa Claude para sugerir interesses relevantes
  const prompt = `Você é especialista em Meta Ads targeting.

Produto: "${produto}"
País: ${pais}
Faixa etária: ${idade_min}-${idade_max} anos
Objetivo: ${objetivo}

Retorne APENAS um JSON com esta estrutura exata:
{
  "interesses": ["interesse1", "interesse2", "interesse3", "interesse4", "interesse5"],
  "comportamentos": ["comportamento1", "comportamento2"],
  "descricao_publico": "descrição em 1 frase do público ideal"
}

Os interesses devem ser termos exatos que existem no Facebook Ads targeting.`;

  const aiRes = await anthropic.messages.create({
    model:      'claude-sonnet-4-20250514',
    max_tokens: 500,
    messages:   [{ role: 'user', content: prompt }],
  });

  const aiText   = aiRes.content[0].text.replace(/```json|```/g, '').trim();
  const aiData   = JSON.parse(aiText);

  // Busca IDs dos interesses na API do Facebook
  const interestIds = await _searchInterests(aiData.interesses, pais);

  // Monta objeto de targeting completo
  const targeting = {
    geo_locations: {
      countries: [pais],
    },
    age_min:    idade_min,
    age_max:    idade_max,
    interests:  interestIds,
    publisher_platforms: ['facebook', 'instagram'],
    facebook_positions:  ['feed', 'story', 'reels'],
    instagram_positions: ['stream', 'story', 'reels'],
  };

  return {
    targeting,
    descricao_publico:   aiData.descricao_publico,
    interesses_sugeridos: aiData.interesses,
    interesses_encontrados: interestIds.length,
  };
}

// ─── 2. CRIAR AD SET ──────────────────────────────────────
async function createAdSet({
  campaign_id,
  nome,
  orcamento_diario,
  objetivo = 'conversoes',
  targeting,
  pixel_id          = null,
  conversion_event  = 'PURCHASE',
  start_time        = null,
}) {
  const url = `${META_BASE}/${AD_ACCOUNT}/adsets`;

  const body = {
    name:              nome,
    campaign_id,
    daily_budget:      Math.round(orcamento_diario * 100),
    billing_event:     BILLING_EVENT_MAP[objetivo] || 'IMPRESSIONS',
    optimization_goal: OPTIMIZATION_GOAL_MAP[objetivo] || 'OFFSITE_CONVERSIONS',
    targeting:         JSON.stringify(targeting),
    status:            'PAUSED',
    start_time:        start_time || new Date(Date.now() + 60000).toISOString(), // 1min a partir de agora
    access_token:      TOKEN,
  };

  // Se tiver pixel, adiciona evento de conversão
  if (pixel_id) {
    body.promoted_object = JSON.stringify({
      pixel_id,
      custom_event_type: conversion_event,
    });
  }

  const res  = await fetch(url, {
    method:  'POST',
    headers: { 'Content-Type': 'application/json' },
    body:    JSON.stringify(body),
  });
  const data = await res.json();

  if (data.error) throw new Error(`[createAdSet] ${data.error.message}`);
  return { adset_id: data.id, nome, campaign_id, objetivo };
}

// ─── 3. CRIAR MÚLTIPLOS AD SETS (públicos diferentes) ─────
async function createMultipleAdSets({ campaign_id, base_nome, orcamento_por_conjunto, produto, pais, objetivo }) {
  const tipos_publico = [
    { sufixo: 'Interesses',  tipo: 'interesses' },
    { sufixo: 'Lookalike 1%', tipo: 'lookalike' },
    { sufixo: 'Broad',        tipo: 'broad' },
  ];

  const resultados = [];

  for (const tp of tipos_publico) {
    let targeting;

    if (tp.tipo === 'interesses') {
      const aud = await buildAudience({ produto, pais, objetivo });
      targeting  = aud.targeting;
    } else if (tp.tipo === 'broad') {
      targeting = {
        geo_locations: { countries: [pais] },
        age_min: 18, age_max: 65,
        publisher_platforms: ['facebook', 'instagram'],
      };
    } else {
      // Lookalike — usa targeting básico (lookalike real precisa de custom audience)
      targeting = {
        geo_locations: { countries: [pais] },
        age_min: 18, age_max: 65,
        publisher_platforms: ['facebook', 'instagram'],
      };
    }

    const adset = await createAdSet({
      campaign_id,
      nome:            `${base_nome} | ${tp.sufixo}`,
      orcamento_diario: orcamento_por_conjunto,
      objetivo,
      targeting,
    });

    resultados.push(adset);
  }

  return resultados;
}

// ─── Helper: buscar IDs de interesses ────────────────────
async function _searchInterests(interesses, pais) {
  const found = [];

  for (const interesse of interesses.slice(0, 5)) {
    try {
      const url  = `${META_BASE}/search?type=adinterest&q=${encodeURIComponent(interesse)}&locale=pt_BR&access_token=${TOKEN}`;
      const res  = await fetch(url);
      const data = await res.json();

      if (data.data && data.data.length > 0) {
        found.push({
          id:   data.data[0].id,
          name: data.data[0].name,
        });
      }
    } catch (e) {
      // ignora erros individuais de busca
    }
  }

  return found;
}

module.exports = {
  buildAudience,
  createAdSet,
  createMultipleAdSets,
};
