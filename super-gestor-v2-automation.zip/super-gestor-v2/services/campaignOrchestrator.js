// ============================================================
// services/campaignOrchestrator.js
// Orquestrador: cria campanha completa de ponta a ponta
// launchCampaign() → cria campanha → ad set → copy → creative → ad
// ============================================================

const { createCampaign, duplicateWinningCampaign } = require('./metaCampaignService');
const { buildAudience, createAdSet }                = require('./metaAdsetService');
const { generateCopy, generateABVariations }        = require('./aiCopyService');
const { uploadImageFromUrl, createAdCreative, createMultipleCreatives } = require('./creativeService');
const { createAd, createMultipleAds }               = require('./metaAdService');

// ─── 1. LANÇAR CAMPANHA COMPLETA ─────────────────────────
// Orquestrador principal: cria tudo do zero
async function launchCampaign({
  // Dados do negócio
  produto,
  publico_descricao,
  link_url,
  page_id,

  // Configurações da campanha
  nome_campanha,
  objetivo        = 'conversoes',
  orcamento_diario,  // R$ por dia (campanha)
  pais            = 'BR',
  idade_min       = 18,
  idade_max       = 65,

  // Criativo
  image_url,        // URL da imagem do anúncio
  instagram_actor_id = null,

  // Status inicial (sempre PAUSED por segurança)
  status_final    = 'PAUSED',
}) {
  const log = [];
  log.push('🚀 Iniciando criação de campanha completa...');

  try {
    // ── PASSO 1: Criar campanha ────────────────────────────
    log.push('1️⃣ Criando campanha...');
    const campanha = await createCampaign({
      nome:             nome_campanha,
      objetivo,
      orcamento_diario,
      status:           'PAUSED',
    });
    log.push(`✅ Campanha criada: ${campanha.campaign_id}`);

    // ── PASSO 2: Gerar audiência ───────────────────────────
    log.push('2️⃣ Gerando audiência com IA...');
    const audiencia = await buildAudience({
      produto,
      pais,
      idade_min,
      idade_max,
      objetivo,
    });
    log.push(`✅ Audiência gerada: ${audiencia.descricao_publico}`);

    // ── PASSO 3: Criar ad set ──────────────────────────────
    log.push('3️⃣ Criando ad set...');
    const adset = await createAdSet({
      campaign_id:     campanha.campaign_id,
      nome:            `${nome_campanha} | Interesses`,
      orcamento_diario: orcamento_diario * 0.8, // 80% do budget no adset principal
      objetivo,
      targeting:       audiencia.targeting,
    });
    log.push(`✅ Ad set criado: ${adset.adset_id}`);

    // ── PASSO 4: Gerar copy com IA ─────────────────────────
    log.push('4️⃣ Gerando copy com IA...');
    const copy = await generateCopy({
      produto,
      publico:  publico_descricao,
      objetivo,
    });
    log.push(`✅ Copy gerada: "${copy.headline}"`);

    // ── PASSO 5: Upload do criativo ────────────────────────
    log.push('5️⃣ Fazendo upload do criativo...');
    const { image_hash } = await uploadImageFromUrl(image_url);
    log.push(`✅ Imagem enviada: ${image_hash}`);

    // ── PASSO 6: Criar ad creative ─────────────────────────
    log.push('6️⃣ Criando ad creative...');
    const creative = await createAdCreative({
      nome:         `Creative | ${nome_campanha}`,
      image_hash,
      page_id,
      headline:     copy.headline,
      primary_text: copy.primary_text,
      description:  copy.description,
      link_url,
      cta:          copy.cta,
      instagram_actor_id,
    });
    log.push(`✅ Creative criado: ${creative.creative_id}`);

    // ── PASSO 7: Criar anúncio ─────────────────────────────
    log.push('7️⃣ Criando anúncio...');
    const ad = await createAd({
      adset_id:    adset.adset_id,
      creative_id: creative.creative_id,
      nome:        `${nome_campanha} | Anúncio 1`,
      status:      status_final,
    });
    log.push(`✅ Anúncio criado: ${ad.ad_id}`);

    log.push('🎉 Campanha criada com sucesso! Revise antes de ativar.');

    return {
      success: true,
      ids: {
        campaign_id: campanha.campaign_id,
        adset_id:    adset.adset_id,
        creative_id: creative.creative_id,
        ad_id:       ad.ad_id,
      },
      audiencia: {
        descricao:   audiencia.descricao_publico,
        interesses:  audiencia.interesses_sugeridos,
      },
      copy: {
        headline:     copy.headline,
        primary_text: copy.primary_text,
        description:  copy.description,
        cta:          copy.cta,
      },
      log,
    };

  } catch (error) {
    log.push(`❌ ERRO: ${error.message}`);
    throw { message: error.message, log };
  }
}

// ─── 2. CRIAR TESTE A/B COMPLETO ─────────────────────────
async function createABTest({
  // Configurações básicas (iguais ao launchCampaign)
  produto,
  publico_descricao,
  link_url,
  page_id,
  nome_base,
  objetivo       = 'conversoes',
  orcamento_diario,
  pais           = 'BR',
  instagram_actor_id = null,

  // A/B config
  image_urls,        // array de imagens (mín 1, máx 3)
  quantidade_variacoes = 3,
}) {
  const log = [];
  log.push('🧪 Iniciando criação de teste A/B...');

  try {
    // ── Criar campanha principal ───────────────────────────
    log.push('1️⃣ Criando campanha A/B...');
    const campanha = await createCampaign({
      nome:             `[A/B] ${nome_base}`,
      objetivo,
      orcamento_diario,
      status:           'PAUSED',
    });

    // ── Criar audiência ────────────────────────────────────
    log.push('2️⃣ Gerando audiência...');
    const audiencia = await buildAudience({ produto, pais, objetivo });

    // ── Criar 1 ad set para o teste ────────────────────────
    log.push('3️⃣ Criando ad set do teste...');
    const adset = await createAdSet({
      campaign_id:     campanha.campaign_id,
      nome:            `[A/B] ${nome_base} | Teste`,
      orcamento_diario,
      objetivo,
      targeting:       audiencia.targeting,
    });

    // ── Gerar variações de copy com IA ─────────────────────
    log.push('4️⃣ Gerando variações de copy com IA...');
    const variacoes_copy = await generateABVariations({
      produto,
      publico:    publico_descricao,
      objetivo,
      quantidade: quantidade_variacoes,
    });

    // ── Upload de todas as imagens ─────────────────────────
    log.push('5️⃣ Fazendo upload das imagens...');
    const image_hashes = [];
    for (const url of image_urls.slice(0, 3)) {
      const { image_hash } = await uploadImageFromUrl(url);
      image_hashes.push(image_hash);
    }

    // ── Criar creatives para cada variação ─────────────────
    log.push('6️⃣ Criando creatives das variações...');
    const creatives = await createMultipleCreatives({
      copies:       variacoes_copy,
      image_hashes,
      page_id,
      link_url,
    });

    // ── Criar anúncios para cada variação ──────────────────
    log.push('7️⃣ Criando anúncios das variações...');
    const ads = await createMultipleAds({
      adset_id:    adset.adset_id,
      creative_ids: creatives.map(c => c.creative_id),
      nome_base,
    });

    log.push(`🎉 Teste A/B criado com ${ads.length} variações!`);

    return {
      success:      true,
      campaign_id:  campanha.campaign_id,
      adset_id:     adset.adset_id,
      variacoes:    ads.map((ad, i) => ({
        variacao:    ad.variacao,
        ad_id:       ad.ad_id,
        creative_id: creatives[i]?.creative_id,
        estrategia:  variacoes_copy[i]?.estrategia,
        copy:        variacoes_copy[i],
      })),
      log,
    };

  } catch (error) {
    log.push(`❌ ERRO: ${error.message}`);
    throw { message: error.message, log };
  }
}

// ─── 3. DUPLICAR E ESCALAR CAMPANHA VENCEDORA ────────────
async function scaleWinningCampaign({
  campaign_id,
  multiplicador_orcamento = 1.5,
  expandir_publico        = true,
  produto                 = null,
  pais                    = 'BR',
}) {
  const log = [];
  log.push('📈 Iniciando escala de campanha vencedora...');

  // Duplica a campanha com orçamento maior
  const nova = await duplicateWinningCampaign({
    campaign_id,
    multiplicador_orcamento,
  });
  log.push(`✅ Campanha duplicada: ${nova.nova_campaign_id}`);
  log.push(`💰 Orçamento: R$${nova.orcamento_original.toFixed(2)} → R$${nova.orcamento_novo.toFixed(2)}`);

  // Se deve expandir público, cria novo ad set broad
  if (expandir_publico && produto) {
    log.push('🌐 Expandindo para público broad...');
    const adset_broad = await createAdSet({
      campaign_id:     nova.nova_campaign_id,
      nome:            '[ESCALA] Público Broad',
      orcamento_diario: nova.orcamento_novo * 0.4, // 40% no broad
      objetivo:        'conversoes',
      targeting: {
        geo_locations: { countries: [pais] },
        age_min: 18, age_max: 65,
        publisher_platforms: ['facebook', 'instagram'],
      },
    });
    log.push(`✅ Ad set broad criado: ${adset_broad.adset_id}`);

    nova.adset_broad_id = adset_broad.adset_id;
  }

  log.push('✅ Escala configurada! Revise e ative quando pronto.');
  return { ...nova, log };
}

module.exports = {
  launchCampaign,
  createABTest,
  scaleWinningCampaign,
};
