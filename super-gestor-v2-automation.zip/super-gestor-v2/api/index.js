// ============================================================
// api/index.js  ← substitui o arquivo existente
// Servidor principal — integra as novas rotas de automação
// ============================================================

require('dotenv').config();
const express = require('express');
const cors    = require('cors');
const path    = require('path');

const app = express();
app.use(cors());
app.use(express.json({ limit: '10mb' }));
app.use(express.static(path.join(__dirname, '../public')));

// ─── Rotas de automação (NOVAS) ───────────────────────────
const automationRoutes = require('../routes/automationRoutes');
app.use('/api', automationRoutes);

// ─── Fallback: serve o frontend ───────────────────────────
app.get('*', (req, res) => {
  res.sendFile(path.join(__dirname, '../public/index.html'));
});

// ─── Start ────────────────────────────────────────────────
const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`🚀 Super Gestor v2 rodando em http://localhost:${PORT}`);
  console.log(`🤖 AI: ${process.env.ANTHROPIC_API_KEY ? '✅' : '❌'}`);
  console.log(`📘 Meta: ${process.env.META_ACCESS_TOKEN ? '✅' : '❌'}`);
});

module.exports = app;
