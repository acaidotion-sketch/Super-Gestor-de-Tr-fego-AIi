// ============================================================
// services/aiCopyService.js
// Geração de copy com IA (Claude) otimizada para Meta Ads
// ============================================================

const Anthropic = require('@anthropic-ai/sdk');

const anthropic = new Anthropic({ apiKey: process.env.ANTHROPIC_API_KEY });

// ─── CTAs válidos no Meta Ads ─────────────────────────────
const VALID_CTAS = [
  'LEARN_MORE',
  'SHOP_NOW',
  'SIGN_UP',
  'SUBSCRIBE',
  'CONTACT_US',
  'BOOK_NOW',
  'DOWNLOAD',
  'GET_QUOTE',
  'WATCH_MORE',
  'APPLY_NOW',
];

const CTA_LABEL_MAP = {
  'Saiba Mais':       'LEARN_MORE',
  'Comprar Agora':    'SHOP_NOW',
  'Cadastre-se':      'SIGN_UP',
  'Inscreva-se':      'SUBSCRIBE',
  'Fale Conosco':     'CONTACT_US',
  'Reservar':         'BOOK_NOW',
  'Baixar':           'DOWNLOAD',
  'Solicitar Orçamento': 'GET_QUOTE',
  'Ver Mais':         'WATCH_MORE',
  'Candidatar-se':    'APPLY_NOW',
};

// ─── Gerar copy principal ────────────────────────────────
async function generateCopy({ produto, publico, objetivo, tom = 'persuasivo', idioma = 'pt-BR' }) {
  const prompt = `Você é um copywriter especialista em Meta Ads com foco em alta conversão.

Produto/Serviço: ${produto}
Público-alvo: ${publico}
Objetivo da campanha: ${objetivo}
Tom: ${tom}
Idioma: ${idioma}

Crie copy otimizada para Meta Ads. Retorne APENAS JSON com esta estrutura exata:
{
  "headline": "título principal (máx 40 caracteres, impactante)",
  "primary_text": "texto principal (máx 125 caracteres, hook forte + benefício + prova social)",
  "description": "descrição curta (máx 30 caracteres, complementa o headline)",
  "cta_label": "um destes exatos: Saiba Mais | Comprar Agora | Cadastre-se | Inscreva-se | Fale Conosco | Solicitar Orçamento",
  "copy_longa": "copy completa para corpo do anúncio (300-500 caracteres, usa gatilhos: urgência, escassez, prova social, autoridade)",
  "hooks": ["hook1 (máx 10 palavras)", "hook2 (máx 10 palavras)", "hook3 (máx 10 palavras)"]
}`;

  const res  = await anthropic.messages.create({
    model:      'claude-sonnet-4-20250514',
    max_tokens: 800,
    messages:   [{ role: 'user', content: prompt }],
  });

  const text  = res.content[0].text.replace(/```json|```/g, '').trim();
  const copy  = JSON.parse(text);

  // Mapeia CTA para o valor aceito pelo Meta
  copy.cta = CTA_LABEL_MAP[copy.cta_label] || 'LEARN_MORE';

  return copy;
}

// ─── Gerar variações para A/B test ───────────────────────
async function generateABVariations({ produto, publico, objetivo, quantidade = 3 }) {
  const prompt = `Você é um copywriter especialista em Meta Ads A/B testing.

Produto/Serviço: ${produto}
Público-alvo: ${publico}
Objetivo: ${objetivo}

Crie ${quantidade} variações diferentes de copy para teste A/B.
Cada variação deve ter uma abordagem distinta:
- Variação A: foco em BENEFÍCIO principal
- Variação B: foco em PROVA SOCIAL/RESULTADO
- Variação C: foco em URGÊNCIA/ESCASSEZ
(adapte para a quantidade solicitada)

Retorne APENAS JSON com esta estrutura:
{
  "variacoes": [
    {
      "id": "A",
      "estrategia": "nome da estratégia usada",
      "headline": "título (máx 40 chars)",
      "primary_text": "texto (máx 125 chars)",
      "description": "descrição (máx 30 chars)",
      "cta_label": "Saiba Mais | Comprar Agora | Cadastre-se | etc",
      "copy_longa": "copy completa (300 chars)"
    }
  ]
}`;

  const res  = await anthropic.messages.create({
    model:      'claude-sonnet-4-20250514',
    max_tokens: 1500,
    messages:   [{ role: 'user', content: prompt }],
  });

  const text = res.content[0].text.replace(/```json|```/g, '').trim();
  const data = JSON.parse(text);

  // Mapeia CTAs
  data.variacoes = data.variacoes.map(v => ({
    ...v,
    cta: CTA_LABEL_MAP[v.cta_label] || 'LEARN_MORE',
  }));

  return data.variacoes;
}

// ─── Gerar copy para remarketing ─────────────────────────
async function generateRemarketingCopy({ produto, publico, dias_remarketing, motivo_nao_compra = null }) {
  const prompt = `Você é especialista em copy de remarketing Meta Ads.

Produto: ${produto}
Público: ${publico} que viu mas não comprou (janela: ${dias_remarketing} dias)
${motivo_nao_compra ? `Provável objeção: ${motivo_nao_compra}` : ''}

Crie copy de remarketing que quebre a objeção e gere urgência.
Retorne APENAS JSON:
{
  "headline": "máx 40 chars - referência ao interesse anterior",
  "primary_text": "máx 125 chars - quebra objeção + nova oferta",
  "description": "máx 30 chars",
  "cta_label": "Saiba Mais | Comprar Agora | etc",
  "copy_longa": "300 chars - história + objeção + solução + CTA urgente"
}`;

  const res  = await anthropic.messages.create({
    model:      'claude-sonnet-4-20250514',
    max_tokens: 600,
    messages:   [{ role: 'user', content: prompt }],
  });

  const text = res.content[0].text.replace(/```json|```/g, '').trim();
  const copy = JSON.parse(text);
  copy.cta   = CTA_LABEL_MAP[copy.cta_label] || 'LEARN_MORE';

  return copy;
}

// ─── Gerar conceito de criativo ───────────────────────────
async function generateCreativeConcept({ produto, publico, objetivo, formato = 'feed' }) {
  const prompt = `Você é um diretor criativo especialista em anúncios Meta Ads.

Produto: ${produto}
Público: ${publico}
Objetivo: ${objetivo}
Formato: ${formato}

Crie um briefing criativo completo. Retorne APENAS JSON:
{
  "conceito": "ideia central do criativo em 1 frase",
  "descricao_visual": "o que deve aparecer na imagem/vídeo (detalhado)",
  "cores_sugeridas": ["#hex1", "#hex2"],
  "estilo": "realista | minimalista | bold | lifestyle | produto | etc",
  "texto_na_imagem": "texto curto para sobrepor na imagem (máx 5 palavras)",
  "prompt_para_ia": "prompt otimizado para gerar a imagem em DALL-E ou Midjourney"
}`;

  const res  = await anthropic.messages.create({
    model:      'claude-sonnet-4-20250514',
    max_tokens: 600,
    messages:   [{ role: 'user', content: prompt }],
  });

  const text = res.content[0].text.replace(/```json|```/g, '').trim();
  return JSON.parse(text);
}

module.exports = {
  generateCopy,
  generateABVariations,
  generateRemarketingCopy,
  generateCreativeConcept,
  VALID_CTAS,
};
