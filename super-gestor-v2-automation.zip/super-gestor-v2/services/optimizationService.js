// ============================================================
// services/optimizationService.js
// Motor de otimização automática de campanhas
// Lê métricas, pausa perdedores, escala vencedores
// ============================================================

const fetch    = require('node-fetch');
const Anthropic = require('@anthropic-ai/sdk');
const { getAdMetrics, pauseAd, activateAd } = require('./metaAdService');
const { updateCampaignBudget }               = require('./metaCampaignService');

const META_BASE  = 'https://graph.facebook.com/v19.0';
const TOKEN      = process.env.META_ACCESS_TOKEN;
const AD_ACCOUNT = process.env.META_AD_ACCOUNT_ID;
const anthropic  = new Anthropic({ apiKey: process.env.ANTHROPIC_API_KEY });

// ─── Regras de otimização (customizáveis) ─────────────────
const DEFAULT_RULES = {
  // Pausar anúncios fracos
  pausar_ctr_abaixo:      1.0,   // CTR < 1% → pausar
  pausar_cpa_acima:       null,  // CPA > X → pausar (null = desabilitado)
  pausar_frequencia_acima: 4.0,  // Frequência > 4 → pausar (criativo cansado)
  pausar_min_impressoes:  1000,  // só pausa se tiver impressões suficientes

  // Escalar campanhas vencedoras
  escalar_roas_acima:     3.0,   // ROAS > 3 → aumentar budget
  escalar_percentual:     0.20,  // aumenta 20% do orçamento
  escalar_max_por_dia:    1,     // máx 1 escala por campanha por dia

  // Período de análise
  periodo: 'last_7d',
};

// ─── 1. OTIMIZAÇÃO AUTOMÁTICA ─────────────────────────────
async function optimizeCampaigns(rules = DEFAULT_RULES) {
  const log      = [];
  const acoes    = [];
  const r        = { ...DEFAULT_RULES, ...rules };

  // Busca todas as campanhas ativas
  const campanhas = await _getActiveCampaigns();
  log.push(`🔍 Analisando ${campanhas.length} campanhas ativas...`);

  for (const campanha of campanhas) {
    // Busca métricas da campanha
    const metricas_campanha = await _getCampaignMetrics(campanha.id, r.periodo);

    // Analisa ROAS para escala de orçamento
    if (metricas_campanha.roas && metricas_campanha.roas >= r.escalar_roas_acima) {
      const orcamento_atual = (campanha.daily_budget || 0) / 100;
      const orcamento_novo  = orcamento_atual * (1 + r.escalar_percentual);

      try {
        await updateCampaignBudget(campanha.id, orcamento_novo);
        const acao = {
          tipo:        'ESCALA_ORCAMENTO',
          campanha_id: campanha.id,
          campanha:    campanha.name,
          motivo:      `ROAS ${metricas_campanha.roas.toFixed(2)} ≥ ${r.escalar_roas_acima}`,
          orcamento_anterior: `R$ ${orcamento_atual.toFixed(2)}`,
          orcamento_novo:     `R$ ${orcamento_novo.toFixed(2)}`,
        };
        acoes.push(acao);
        log.push(`✅ [ESCALA] ${campanha.name}: R$${orcamento_atual.toFixed(0)} → R$${orcamento_novo.toFixed(0)} (ROAS: ${metricas_campanha.roas.toFixed(2)})`);
      } catch (e) {
        log.push(`❌ Erro ao escalar ${campanha.name}: ${e.message}`);
      }
    }

    // Busca anúncios da campanha para análise individual
    const ads = await _getAdsFromCampaign(campanha.id);

    for (const ad of ads) {
      if (ad.effective_status !== 'ACTIVE') continue;

      try {
        const m = await getAdMetrics(ad.id, r.periodo);

        // Pula anúncios com impressões insuficientes
        if (m.impressions < r.pausar_min_impressoes) continue;

        let deve_pausar  = false;
        let motivo_pausa = '';

        // Regra: CTR baixo
        if (m.ctr < r.pausar_ctr_abaixo) {
          deve_pausar  = true;
          motivo_pausa = `CTR ${m.ctr.toFixed(2)}% < ${r.pausar_ctr_abaixo}%`;
        }

        // Regra: Frequência alta (criativo cansado)
        if (m.frequency > r.pausar_frequencia_acima) {
          deve_pausar  = true;
          motivo_pausa = `Frequência ${m.frequency.toFixed(1)} > ${r.pausar_frequencia_acima}`;
        }

        // Regra: CPA alto (se configurado)
        if (r.pausar_cpa_acima && m.spend > 0 && m.conversoes > 0) {
          const cpa = m.spend / m.conversoes;
          if (cpa > r.pausar_cpa_acima) {
            deve_pausar  = true;
            motivo_pausa = `CPA R$${cpa.toFixed(2)} > R$${r.pausar_cpa_acima}`;
          }
        }

        if (deve_pausar) {
          await pauseAd(ad.id);
          const acao = {
            tipo:        'PAUSA_ANUNCIO',
            ad_id:       ad.id,
            ad_nome:     ad.name,
            campanha_id: campanha.id,
            motivo:      motivo_pausa,
            metricas:    { ctr: m.ctr, frequencia: m.frequency, impressoes: m.impressions, gasto: m.spend },
          };
          acoes.push(acao);
          log.push(`⏸ [PAUSADO] ${ad.name}: ${motivo_pausa}`);
        }
      } catch (e) {
        log.push(`⚠️ Erro ao analisar ad ${ad.id}: ${e.message}`);
      }
    }
  }

  // Gera relatório de otimização com IA
  const relatorio = await _gerarRelatorioOtimizacao(acoes, log);

  return {
    timestamp:       new Date().toISOString(),
    campanhas_analisadas: campanhas.length,
    acoes_executadas:    acoes.length,
    acoes,
    log,
    relatorio_ia:    relatorio,
  };
}

// ─── 2. ANÁLISE DE PERFORMANCE GERAL DA CONTA ────────────
async function analyzeAccountPerformance(periodo = 'last_30d') {
  const fields = 'impressions,clicks,spend,cpm,cpc,ctr,actions,action_values,frequency,reach';
  const url    = `${META_BASE}/${AD_ACCOUNT}/insights?fields=${fields}&date_preset=${periodo}&access_token=${TOKEN}`;

  const res  = await fetch(url);
  const data = await res.json();

  if (data.error) throw new Error(`[analyzeAccount] ${data.error.message}`);

  const m = data.data?.[0] || {};
  const purchase_value = m.action_values?.find(a => a.action_type === 'purchase')?.value || 0;
  const conversoes     = m.actions?.find(a => a.action_type === 'purchase')?.value || 0;
  const roas           = m.spend && purchase_value > 0 ? (purchase_value / m.spend).toFixed(2) : null;

  const metricas = {
    periodo,
    impressions: parseInt(m.impressions || 0),
    clicks:      parseInt(m.clicks || 0),
    spend:       parseFloat(m.spend || 0),
    cpm:         parseFloat(m.cpm || 0),
    cpc:         parseFloat(m.cpc || 0),
    ctr:         parseFloat(m.ctr || 0),
    frequency:   parseFloat(m.frequency || 0),
    reach:       parseInt(m.reach || 0),
    roas:        roas ? parseFloat(roas) : null,
    conversoes:  parseInt(conversoes),
    receita:     parseFloat(purchase_value),
  };

  // Diagnóstico com IA
  const diagnostico = await _diagnosticarConta(metricas);

  return { metricas, diagnostico };
}

// ─── 3. IDENTIFICAR VENCEDORES E PERDEDORES ───────────────
async function rankAds(campaign_id, periodo = 'last_7d') {
  const ads = await _getAdsFromCampaign(campaign_id);
  const ranked = [];

  for (const ad of ads) {
    try {
      const m = await getAdMetrics(ad.id, periodo);
      ranked.push({
        ad_id:   ad.id,
        nome:    ad.name,
        status:  ad.effective_status,
        metricas: m,
        score:   _calcularScore(m),
      });
    } catch (e) {
      // ignora
    }
  }

  ranked.sort((a, b) => b.score - a.score);

  return {
    vencedores: ranked.slice(0, 3),
    perdedores: ranked.slice(-3).reverse(),
    todos:      ranked,
  };
}

// ─── Helpers internos ─────────────────────────────────────

async function _getActiveCampaigns() {
  const url  = `${META_BASE}/${AD_ACCOUNT}/campaigns`
    + `?fields=id,name,status,objective,daily_budget`
    + `&effective_status=['ACTIVE']`
    + `&access_token=${TOKEN}`;

  const res  = await fetch(url);
  const data = await res.json();
  return data.data || [];
}

async function _getCampaignMetrics(campaign_id, periodo) {
  const fields = 'spend,impressions,clicks,ctr,actions,action_values';
  const url    = `${META_BASE}/${campaign_id}/insights?fields=${fields}&date_preset=${periodo}&access_token=${TOKEN}`;

  const res  = await fetch(url);
  const data = await res.json();

  const m = data.data?.[0] || {};
  const purchase_value = m.action_values?.find(a => a.action_type === 'purchase')?.value || 0;
  const roas           = m.spend && purchase_value > 0 ? purchase_value / parseFloat(m.spend) : null;

  return {
    spend:  parseFloat(m.spend || 0),
    clicks: parseInt(m.clicks || 0),
    ctr:    parseFloat(m.ctr || 0),
    roas,
  };
}

async function _getAdsFromCampaign(campaign_id) {
  const url  = `${META_BASE}/${campaign_id}/ads`
    + `?fields=id,name,effective_status&access_token=${TOKEN}`;

  const res  = await fetch(url);
  const data = await res.json();
  return data.data || [];
}

function _calcularScore(m) {
  // Score composto: CTR (40%) + ROAS (40%) + Frequência invertida (20%)
  const ctr_score  = Math.min(m.ctr * 20, 40);   // max 40 pts
  const roas_score = m.roas ? Math.min(m.roas * 8, 40) : 0; // max 40 pts
  const freq_score = Math.max(20 - (m.frequency * 5), 0);   // max 20 pts
  return ctr_score + roas_score + freq_score;
}

async function _gerarRelatorioOtimizacao(acoes, log) {
  if (acoes.length === 0) return 'Nenhuma ação executada. Campanhas dentro dos parâmetros normais.';

  const pausas  = acoes.filter(a => a.tipo === 'PAUSA_ANUNCIO').length;
  const escalas = acoes.filter(a => a.tipo === 'ESCALA_ORCAMENTO').length;

  const prompt = `Você é um gestor de tráfego pago sênior. Analise as ações de otimização executadas:

Pausas de anúncios: ${pausas}
Escalas de orçamento: ${escalas}
Log: ${log.slice(0, 10).join(' | ')}

Escreva um resumo executivo em 2-3 frases sobre o que foi feito e o impacto esperado.`;

  const res = await anthropic.messages.create({
    model:      'claude-sonnet-4-20250514',
    max_tokens: 200,
    messages:   [{ role: 'user', content: prompt }],
  });

  return res.content[0].text;
}

async function _diagnosticarConta(metricas) {
  const prompt = `Gestor de tráfego sênior. Diagnóstico rápido da conta Meta Ads:

CTR: ${metricas.ctr.toFixed(2)}% | CPM: R$${metricas.cpm.toFixed(2)} | CPC: R$${metricas.cpc.toFixed(2)}
ROAS: ${metricas.roas || 'N/A'} | Gasto: R$${metricas.spend.toFixed(2)} | Frequência: ${metricas.frequency.toFixed(1)}
Período: ${metricas.periodo}

Retorne APENAS JSON:
{
  "status_geral": "CRÍTICO | ATENÇÃO | BOM | EXCELENTE",
  "principais_problemas": ["problema1", "problema2"],
  "acoes_prioritarias": ["acao1", "acao2", "acao3"],
  "score": número 0-100
}`;

  const res  = await anthropic.messages.create({
    model:      'claude-sonnet-4-20250514',
    max_tokens: 400,
    messages:   [{ role: 'user', content: prompt }],
  });

  const text = res.content[0].text.replace(/```json|```/g, '').trim();
  return JSON.parse(text);
}

module.exports = {
  optimizeCampaigns,
  analyzeAccountPerformance,
  rankAds,
  DEFAULT_RULES,
};
