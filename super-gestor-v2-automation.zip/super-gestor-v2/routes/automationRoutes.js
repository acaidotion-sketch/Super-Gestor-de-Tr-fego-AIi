// ============================================================
// routes/automationRoutes.js
// Todas as rotas de automação da API
// ============================================================

const express  = require('express');
const router   = express.Router();

const { launchCampaign, createABTest, scaleWinningCampaign } = require('../services/campaignOrchestrator');
const { optimizeCampaigns, analyzeAccountPerformance, rankAds, DEFAULT_RULES } = require('../services/optimizationService');
const { generateCopy, generateABVariations, generateCreativeConcept } = require('../services/aiCopyService');
const { buildAudience }          = require('../services/metaAdsetService');
const { uploadImageFromUrl }     = require('../services/creativeService');
const { listCampaigns, pauseCampaign, activateCampaign, updateCampaignBudget } = require('../services/metaCampaignService');
const { rankAds: rankAdsService } = require('../services/optimizationService');

// ─── Middleware: log de request ───────────────────────────
router.use((req, res, next) => {
  console.log(`[${new Date().toISOString()}] ${req.method} ${req.path}`);
  next();
});

// ============================================================
// 🚀 LANÇAMENTO DE CAMPANHA COMPLETA
// POST /api/launch-campaign
// Body: { produto, publico_descricao, link_url, page_id,
//         nome_campanha, objetivo, orcamento_diario,
//         image_url, pais?, idade_min?, idade_max? }
// ============================================================
router.post('/launch-campaign', async (req, res) => {
  try {
    const resultado = await launchCampaign(req.body);
    res.json({
      success: true,
      message: 'Campanha criada com sucesso! Revise no Meta Ads antes de ativar.',
      ...resultado,
    });
  } catch (err) {
    res.status(500).json({
      success: false,
      error:   err.message || err,
      log:     err.log || [],
    });
  }
});

// ============================================================
// 🧪 CRIAR TESTE A/B
// POST /api/create-ab-test
// Body: { produto, publico_descricao, link_url, page_id,
//         nome_base, objetivo, orcamento_diario,
//         image_urls (array), quantidade_variacoes? }
// ============================================================
router.post('/create-ab-test', async (req, res) => {
  try {
    const resultado = await createABTest(req.body);
    res.json({
      success: true,
      message: `Teste A/B criado com ${resultado.variacoes.length} variações!`,
      ...resultado,
    });
  } catch (err) {
    res.status(500).json({
      success: false,
      error:   err.message || err,
      log:     err.log || [],
    });
  }
});

// ============================================================
// ⚡ OTIMIZAÇÃO AUTOMÁTICA DE CAMPANHAS
// POST /api/optimize-campaigns
// Body: { rules? } → usa DEFAULT_RULES se não informado
// ============================================================
router.post('/optimize-campaigns', async (req, res) => {
  try {
    const { rules } = req.body;
    const resultado = await optimizeCampaigns(rules);
    res.json({
      success: true,
      message: `Otimização concluída. ${resultado.acoes_executadas} ações executadas.`,
      ...resultado,
    });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// ============================================================
// 📊 ANÁLISE DE PERFORMANCE DA CONTA
// GET /api/account-performance?periodo=last_30d
// ============================================================
router.get('/account-performance', async (req, res) => {
  try {
    const { periodo = 'last_30d' } = req.query;
    const resultado = await analyzeAccountPerformance(periodo);
    res.json({ success: true, ...resultado });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// ============================================================
// 📈 ESCALAR CAMPANHA VENCEDORA
// POST /api/scale-campaign
// Body: { campaign_id, multiplicador_orcamento?, expandir_publico?, produto?, pais? }
// ============================================================
router.post('/scale-campaign', async (req, res) => {
  try {
    const resultado = await scaleWinningCampaign(req.body);
    res.json({
      success: true,
      message: `Campanha escalada! Orçamento: R$${resultado.orcamento_novo.toFixed(2)}/dia`,
      ...resultado,
    });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// ============================================================
// ✍️ GERAR COPY COM IA
// POST /api/generate-copy
// Body: { produto, publico, objetivo, tom?, idioma? }
// ============================================================
router.post('/generate-copy', async (req, res) => {
  try {
    const copy = await generateCopy(req.body);
    res.json({ success: true, copy });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// ============================================================
// 🎨 GERAR CONCEITO DE CRIATIVO
// POST /api/generate-creative-concept
// Body: { produto, publico, objetivo, formato? }
// ============================================================
router.post('/generate-creative-concept', async (req, res) => {
  try {
    const conceito = await generateCreativeConcept(req.body);
    res.json({ success: true, conceito });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// ============================================================
// 🎯 CONSTRUIR AUDIÊNCIA
// POST /api/build-audience
// Body: { produto, pais?, idade_min?, idade_max?, objetivo? }
// ============================================================
router.post('/build-audience', async (req, res) => {
  try {
    const audiencia = await buildAudience(req.body);
    res.json({ success: true, ...audiencia });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// ============================================================
// 🖼️ UPLOAD DE IMAGEM
// POST /api/creative/upload-url
// Body: { image_url }
// ============================================================
router.post('/creative/upload-url', async (req, res) => {
  try {
    const { image_url } = req.body;
    if (!image_url) return res.status(400).json({ error: 'image_url é obrigatório' });
    const resultado = await uploadImageFromUrl(image_url);
    res.json({ success: true, ...resultado });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// ============================================================
// 🏆 RANKING DE ANÚNCIOS
// GET /api/rank-ads/:campaign_id?periodo=last_7d
// ============================================================
router.get('/rank-ads/:campaign_id', async (req, res) => {
  try {
    const { campaign_id } = req.params;
    const { periodo = 'last_7d' } = req.query;
    const resultado = await rankAds(campaign_id, periodo);
    res.json({ success: true, ...resultado });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// ============================================================
// 📋 LISTAR CAMPANHAS
// GET /api/campaigns?status=ACTIVE
// ============================================================
router.get('/campaigns', async (req, res) => {
  try {
    const { status } = req.query;
    const campanhas  = await listCampaigns({ status_filter: status });
    res.json({ success: true, total: campanhas.length, campanhas });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// ============================================================
// 💰 ATUALIZAR ORÇAMENTO
// POST /api/campaigns/:id/budget
// Body: { orcamento_diario }
// ============================================================
router.post('/campaigns/:id/budget', async (req, res) => {
  try {
    const { id }               = req.params;
    const { orcamento_diario } = req.body;
    const resultado            = await updateCampaignBudget(id, orcamento_diario);
    res.json({ success: true, ...resultado });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// ============================================================
// ⏸ PAUSAR / ▶️ ATIVAR CAMPANHA
// POST /api/campaigns/:id/pause
// POST /api/campaigns/:id/activate
// ============================================================
router.post('/campaigns/:id/pause', async (req, res) => {
  try {
    const resultado = await pauseCampaign(req.params.id);
    res.json({ success: true, ...resultado });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

router.post('/campaigns/:id/activate', async (req, res) => {
  try {
    const resultado = await activateCampaign(req.params.id);
    res.json({ success: true, ...resultado });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// ============================================================
// ❤️ HEALTH CHECK
// GET /api/health
// ============================================================
router.get('/health', (req, res) => {
  res.json({
    status:          'ok',
    timestamp:       new Date().toISOString(),
    meta_configurado: !!(process.env.META_ACCESS_TOKEN && process.env.META_AD_ACCOUNT_ID),
    ai_configurado:   !!process.env.ANTHROPIC_API_KEY,
    versao:          '2.0.0',
    endpoints:       [
      'POST /api/launch-campaign',
      'POST /api/create-ab-test',
      'POST /api/optimize-campaigns',
      'GET  /api/account-performance',
      'POST /api/scale-campaign',
      'POST /api/generate-copy',
      'POST /api/generate-creative-concept',
      'POST /api/build-audience',
      'POST /api/creative/upload-url',
      'GET  /api/rank-ads/:campaign_id',
      'GET  /api/campaigns',
      'POST /api/campaigns/:id/budget',
      'POST /api/campaigns/:id/pause',
      'POST /api/campaigns/:id/activate',
    ],
  });
});

module.exports = router;
