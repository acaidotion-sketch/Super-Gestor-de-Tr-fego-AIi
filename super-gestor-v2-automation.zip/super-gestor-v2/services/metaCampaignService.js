// ============================================================
// services/metaCampaignService.js
// Criação, duplicação e controle de campanhas no Meta Ads
// ============================================================

const fetch = require('node-fetch');

const META_BASE = 'https://graph.facebook.com/v19.0';
const TOKEN = process.env.META_ACCESS_TOKEN;
const AD_ACCOUNT = process.env.META_AD_ACCOUNT_ID;

// ─── Mapeamento de objetivos ──────────────────────────────
const OBJECTIVE_MAP = {
  conversoes:      'OUTCOME_SALES',
  leads:           'OUTCOME_LEADS',
  trafego:         'OUTCOME_TRAFFIC',
  engajamento:     'OUTCOME_ENGAGEMENT',
  reconhecimento:  'OUTCOME_AWARENESS',
  app:             'OUTCOME_APP_PROMOTION',
};

// ─── Criar campanha ───────────────────────────────────────
async function createCampaign({ nome, objetivo, orcamento_diario, status = 'PAUSED' }) {
  const url = `${META_BASE}/${AD_ACCOUNT}/campaigns`;

  const body = {
    name:                   nome,
    objective:              OBJECTIVE_MAP[objetivo] || 'OUTCOME_SALES',
    status,
    daily_budget:           Math.round(orcamento_diario * 100), // em centavos
    special_ad_categories:  [],
    access_token:           TOKEN,
  };

  const res  = await fetch(url, {
    method:  'POST',
    headers: { 'Content-Type': 'application/json' },
    body:    JSON.stringify(body),
  });
  const data = await res.json();

  if (data.error) throw new Error(`[createCampaign] ${data.error.message}`);
  return { campaign_id: data.id, nome, objetivo, status };
}

// ─── Listar campanhas ─────────────────────────────────────
async function listCampaigns({ limit = 20, status_filter = null } = {}) {
  let url = `${META_BASE}/${AD_ACCOUNT}/campaigns`
    + `?fields=id,name,status,objective,daily_budget,lifetime_budget,start_time,stop_time`
    + `&limit=${limit}`
    + `&access_token=${TOKEN}`;

  if (status_filter) url += `&effective_status=['${status_filter}']`;

  const res  = await fetch(url);
  const data = await res.json();

  if (data.error) throw new Error(`[listCampaigns] ${data.error.message}`);
  return data.data || [];
}

// ─── Pausar campanha ──────────────────────────────────────
async function pauseCampaign(campaign_id) {
  return _updateCampaignStatus(campaign_id, 'PAUSED');
}

// ─── Ativar campanha ──────────────────────────────────────
async function activateCampaign(campaign_id) {
  return _updateCampaignStatus(campaign_id, 'ACTIVE');
}

// ─── Atualizar orçamento da campanha ──────────────────────
async function updateCampaignBudget(campaign_id, novo_orcamento_diario) {
  const url  = `${META_BASE}/${campaign_id}`;
  const body = {
    daily_budget:  Math.round(novo_orcamento_diario * 100),
    access_token:  TOKEN,
  };

  const res  = await fetch(url, {
    method:  'POST',
    headers: { 'Content-Type': 'application/json' },
    body:    JSON.stringify(body),
  });
  const data = await res.json();

  if (data.error) throw new Error(`[updateCampaignBudget] ${data.error.message}`);
  return { campaign_id, novo_orcamento_diario, success: true };
}

// ─── Duplicar campanha vencedora (escala) ─────────────────
async function duplicateWinningCampaign({
  campaign_id,
  multiplicador_orcamento = 1.5,
  novo_nome = null,
}) {
  // 1. Busca dados da campanha original
  const url  = `${META_BASE}/${campaign_id}?fields=name,objective,daily_budget,status&access_token=${TOKEN}`;
  const res  = await fetch(url);
  const orig = await res.json();

  if (orig.error) throw new Error(`[duplicateWinningCampaign] ${orig.error.message}`);

  // 2. Calcula novo orçamento
  const orcamento_original = (orig.daily_budget || 5000) / 100; // converte de centavos
  const orcamento_novo     = orcamento_original * multiplicador_orcamento;

  // 3. Cria nova campanha com orçamento maior
  const nova = await createCampaign({
    nome:           novo_nome || `[ESCALA] ${orig.name}`,
    objetivo:       Object.keys(OBJECTIVE_MAP).find(k => OBJECTIVE_MAP[k] === orig.objective) || 'conversoes',
    orcamento_diario: orcamento_novo,
    status:         'PAUSED', // sempre começa pausada para revisão
  });

  return {
    original_campaign_id:  campaign_id,
    nova_campaign_id:      nova.campaign_id,
    orcamento_original,
    orcamento_novo,
    multiplicador:         multiplicador_orcamento,
  };
}

// ─── Helper: atualizar status ─────────────────────────────
async function _updateCampaignStatus(campaign_id, status) {
  const url  = `${META_BASE}/${campaign_id}`;
  const body = { status, access_token: TOKEN };

  const res  = await fetch(url, {
    method:  'POST',
    headers: { 'Content-Type': 'application/json' },
    body:    JSON.stringify(body),
  });
  const data = await res.json();

  if (data.error) throw new Error(`[updateStatus] ${data.error.message}`);
  return { campaign_id, status, success: true };
}

module.exports = {
  createCampaign,
  listCampaigns,
  pauseCampaign,
  activateCampaign,
  updateCampaignBudget,
  duplicateWinningCampaign,
};
